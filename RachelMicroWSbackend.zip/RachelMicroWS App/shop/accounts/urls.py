from django.urls import path
from .views import index,register
app_name = 'accounts'
urlpatterns = [
    path('index',index, name='index'),
    path('register',register, name='register'),
]