from django.db import models

# Create your models here.
class customer(models.Model):
    username = models.CharField(null=True,blank=True,max_length=40)
    phone = models.CharField(null=True,blank=True,max_length=40)
    email = models.CharField(null=True,blank=True,max_length=40)
    race = models.CharField(null=True,blank=True,max_length=40)
    adress = models.CharField(null=True,blank=True,max_length=30)
    date_birth = models.CharField(null=True,blank=True,max_length=70)
    age = models.IntegerField(null=True,blank=True)
