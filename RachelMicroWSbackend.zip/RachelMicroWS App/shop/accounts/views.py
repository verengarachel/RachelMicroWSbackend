from django.shortcuts import render
from . import models  

# Create your views here.
# first_customer = customer.objects.create(
#     username = 'rachel',
#     date_birth = '20/04/1994',
#     adress = '54 Patpalmer',
#     email = 'verengarachel@gmail.com',
#     age = 27,
#     phone = '0773615596',
    

# )

def index(request):
    first_customer = models.customer.objects.create(
        username = 'rachel',
        date_birth = '20/04/1994',
        adress = '54 Patpalmer',
        email = 'verengarachel@gmail.com',
        age = 27,
        phone = '0773615596',)
    context = {
        'customer':first_customer,
        'name':'hello'
    }
    print(context)    

    return render(request,'index.html',context)
def register(request):
    if request.method == "POST":
        username = request.POST['username']
        phone = request.POST['phone']
        adress = request.POST['adress']
        age = request.POST['age']
        email = request.POST['email']
        date_birth = request.POST['date_birth']
        customer = models.customer(
            username = username,
            phone = phone,
            adress = adress,
            age = age,
            email = email,
            date_birth = date_birth,
        )
        customer.save()
    context = {
        'name': customer.username
    }
    return render(request,'index.html',context)
        
