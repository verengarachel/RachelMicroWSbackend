from django.shortcuts import render

# Create your views here.
from . models import student
def Create_register(request):
    register = student.objects.create(
        username = "rachel verenga",
        age = "27",
        email = "verengarachel@gmail.com",
    )

    context = {
        "data":register,
    }

    return render(request,"index.html",context)